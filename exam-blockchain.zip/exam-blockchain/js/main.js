
let addressAccount;
import {ABI,smartContractAddr} from './config.js'

let web3 = new Web3(window.ethereum)
let contract = new web3.eth.Contract(ABI,smartContractAddr)
const connectAccount = async ()=>{
    console.log('hhh')

    await window.ethereum.request({method:"eth_requestAccounts" })
    addressAccount=(await window.ethereum.request({method:"eth_accounts"}))[0]
    
    var balance = await web3.eth.getBalance(addressAccount)
    

    acountBalance.innerText=parseFloat(balance)/10**18 +" ETH"
    acountAddress.innerText=addressAccount
    displayInfo()
}



btnConnect.addEventListener('click',connectAccount)

const displayInfo =async ()=>{
    try {
      
        const minimumtoDeposit = await contract.methods.minimunToDeposite().call()
        console.log(minimumtoDeposit)
        minTodeposit.innerText =  parseFloat(minimumtoDeposit)/10**18 +" ETH"
        const yourDeposit =  await contract.methods.listAmountsWallets(addressAccount).call()
     
        mydeposit.innerText= parseFloat(yourDeposit)/10**18 +" ETH"

       
        




        
    } catch (error) {
        
    }
}

displayInfo()

Withdraw.addEventListener('click',async()=>{

    const amountInputValue= amountInput.value
    if(!amountInputValue){
        alert('cannot widthdraw 0')
        return
    }
   

    try {
        let result = await contract.methods.withdraw().send({
            from: addressAccount,
            value:amountInput.value
        })
        console.log(result)
        alert('Wo hooo you widthdraw successfully')
        displayInfo()

        
    } catch (error) {
        alert(` ${error} Oooops Something went wrong`)
    }

})
Deposit.addEventListener('click',async()=>{
    const amountInputValue= amountInput.value
    if(!amountInputValue){
        alert('cannot deposite ')
        return
    }
    
    try {
        let result = await contract.methods.deposite().send({
            from: addressAccount,
            value:amountInput.value
        })
        console.log(result)
        alert('Wo hooo you deposite successfully')
        displayInfo()

        
    } catch (error) {
        alert(` ${error} Oooops Something went wrong`)
    }
})

